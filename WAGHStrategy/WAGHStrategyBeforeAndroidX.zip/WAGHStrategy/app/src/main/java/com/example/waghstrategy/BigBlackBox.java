package com.example.waghstrategy;

import android.database.sqlite.SQLiteDatabase;

import androidx.lifecycle.ViewModel;

public class BigBlackBox extends ViewModel {
    boolean isOnline;
    SQLiteDatabase cachedUsersDB;


    //TODO HTTP connection class? Ip of server?

}
