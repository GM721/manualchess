package com.example.waghstrategy;

import android.provider.BaseColumns;

public class LoggedUsersContract {

    private LoggedUsersContract(){}

    public static class Authorisation implements BaseColumns{
        public static final String tableName = "Authorised users";
        public static final String email = "Email";
        public static final String  nickname = "Nickname";
        public static final String password = "Password";
        public static final String  SQLCreateDB = "CREATE TABLE " + tableName + "( " +
                nickname + " TINYTEXT PRIMARY KEY," + email + " TINYTEXT," +
                password + " TINYTEXT)";
        public static final String SQLDeleteDB = "DROP TABLE IF EXISTS " + tableName;

    }
}
