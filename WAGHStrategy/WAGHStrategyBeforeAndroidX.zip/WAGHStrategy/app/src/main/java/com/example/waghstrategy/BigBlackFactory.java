package com.example.waghstrategy;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class BigBlackFactory implements ViewModelProvider.Factory {
    Context appContext;
    BigBlackFactory(Context context){
        appContext = context;
    }
    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if(modelClass.equals(BigBlackBox.class)){
            BigBlackBox bbb = new BigBlackBox();
            bbb.cachedUsersDB = new SQLiteCachedUsers(appContext).getWritableDatabase();
            bbb.isOnline=false;//TODO открыть интернет соединение
            return (T) bbb;
        }
        else return null;
    }
}
